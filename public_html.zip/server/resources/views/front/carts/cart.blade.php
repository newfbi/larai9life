@extends('layouts.front.app')

@section('content')
        <div class="container product-in-cart-list">
            @if(!$cartItems->isEmpty())
                <div class="row">
                    <div class="col-md-12">
                        <ol class="breadcrumb">
                            <li><a href="{{ route('home') }}"> <i class="fa fa-home"></i> Home</a></li>
                            <li class="active">Carrinho</li>
                        </ol>
                    </div>
                    <div class="col-md-12 content">
                        <div class="box-body">
                            @include('layouts.errors-and-messages')
                        </div>
                        <h3><i class="fa fa-cart-plus"></i> Shopping Cart</h3>
                        <table class="table table-striped">
                            <thead>
                                <th class="col-md-2 col-lg-2">Produto</th>
                                <th class="col-md-2 col-lg-5">Nome</th>
                                <th class="col-md-2 col-lg-2">Quantidade</th>
                                <th class="col-md-2 col-lg-1"></th>
                                <th class="col-md-2 col-lg-2">Preço</th>
                            </thead>
                            <tfoot>
                            <tr>
                                <td class="bg-warning">Subtotal</td>
                                <td class="bg-warning"></td>
                                <td class="bg-warning"></td>
                                <td class="bg-warning"></td>
                                <td class="bg-warning">{{config('cart.currency')}} {{ $subtotal }}</td>
                            </tr>
                            @if(isset($shippingFee) && $shippingFee != 0)
                            <tr>
                                <td class="bg-warning">Entrega</td>
                                <td class="bg-warning"></td>
                                <td class="bg-warning"></td>
                                <td class="bg-warning"></td>
                                <td class="bg-warning">{{config('cart.currency')}} {{ $shippingFee }}</td>
                            </tr>
                            @endif
                            <tr>
                                <td class="bg-warning">Taxa</td>
                                <td class="bg-warning"></td>
                                <td class="bg-warning"></td>
                                <td class="bg-warning"></td>
                                <td class="bg-warning">{{config('cart.currency')}} {{ number_format($tax, 2) }}</td>
                            </tr>
                            <tr>
                                <td class="bg-success">Total</td>
                                <td class="bg-success"></td>
                                <td class="bg-success"></td>
                                <td class="bg-success"></td>
                                <td class="bg-success">{{config('cart.currency')}} {{ $total }}</td>
                            </tr>
                            </tfoot>
                            <tbody>
                            @foreach($cartItems as $cartItem)
                                <tr>
                                    <td>
                                        <a href="{{ route('front.get.product', [$cartItem->product->slug]) }}" class="hover-border">
                                            @if(isset($cartItem->cover))
                                                <img src="{{ asset("storage/$cartItem->cover") }}" alt="{{ $cartItem->name }}" class="img-responsive img-thumbnail">
                                            @else
                                                <img src="https://placehold.it/120x120" alt="" class="img-responsive img-thumbnail">
                                            @endif
                                        </a>
                                    </td>
                                    <td>
                                        <h3>{{ $cartItem->name }}</h3>
                                        @if(isset($cartItem->options))
                                            @foreach($cartItem->options as $key => $option)
                                                <span class="label label-primary">{{ $key }} : {{ $option }}</span>
                                            @endforeach
                                        @endif
                                        <div class="product-description">
                                            {!! $cartItem->product->description !!}
                                        </div>
                                    </td>
                                    <td>
                                        <form action="{{ route('cart.update', $cartItem->rowId) }}" class="form-inline" method="post">
                                            {{ csrf_field() }}
                                            <input type="hidden" name="_method" value="put">
                                            <div class="input-group">
                                                <input  onkeydown="return false" required type="number" name="quantity" value="{{ $cartItem->qty }}" min="1" max="99" class="form-control"/>
                                                <span class="input-group-btn"><button class="btn btn-default">Atualizar</button></span>
                                            </div>
                                        </form>
                                    </td>
                                    <td>
                                        <form action="{{ route('cart.destroy', $cartItem->rowId) }}" method="post">
                                            {{ csrf_field() }}
                                            <input type="hidden" name="_method" value="delete">
                                            <button onclick="return confirm('Are you sure?')" class="btn btn-danger"><i class="fa fa-times"></i></button>
                                        </form>
                                    </td>
                                    <td>{{config('cart.currency')}} {{ number_format($cartItem->price, 2) }}</td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                        <hr>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="btn-group pull-right">
                                    <a href="{{ route('home') }}" class="btn btn-default">Continar Escolhendo</a>
                                    <a href="{{ route('checkout.index') }}" class="btn btn-primary">Finalizar Pedido</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @else
                <div class="row">
                    <div class="col-md-12">
                        <p class="alert alert-warning">Nenhum produto no carrinho ainda. <a href="{{ route('home') }}">Escolha agora!</a></p>
                    </div>
                </div>
            @endif
        </div>
@endsection
@section('css')
    <style type="text/css">
        .product-description {
            padding: 10px 0;
        }
        .product-description p {
            line-height: 18px;
            font-size: 14px;
        }
    </style>
@endsection