<?php

return [
    'name' => env('PAYMENT_METHODS', 'paypal')
];