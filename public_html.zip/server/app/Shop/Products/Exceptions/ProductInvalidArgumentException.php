<?php

namespace App\Shop\Products\Exceptions;

use Doctrine\Instantiator\Exception\InvalidArgumentException;

class ProductInvalidArgumentException extends InvalidArgumentException
{
}
