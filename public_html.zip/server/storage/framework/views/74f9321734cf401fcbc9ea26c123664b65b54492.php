<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">

    <?php echo $__env->make('layouts.errors-and-messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Default box -->
        <?php if($product): ?>
            <div class="box">
                <div class="box-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <td class="col-md-2">Name</td>
                                <td class="col-md-3">Description</td>
                                <td class="col-md-3">Cover</td>
                                <td class="col-md-2">Quantity</td>
                                <td class="col-md-2">Price</td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?php echo e($product->name); ?></td>
                                <td><?php echo e($product->description); ?></td>
                                <td>
                                    <?php if(isset($product->cover)): ?>
                                        <img src="<?php echo e(asset("storage/$product->cover")); ?>" class="img-responsive" alt="">
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($product->quantity); ?></td>
                                <td><?php echo e(config('cart.currency')); ?> <?php echo e($product->price); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <!-- /.box-body -->
                <div class="box-footer">
                    <div class="btn-group">
                        <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-default btn-sm">Back</a>
                    </div>
                </div>
            </div>
            <!-- /.box -->
        <?php endif; ?>

    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>