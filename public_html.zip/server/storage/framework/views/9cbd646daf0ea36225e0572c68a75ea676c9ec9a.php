<div class="dropdown show">
	<a class="btn dropdown-toggle" href="<?php echo e(route('front.category.slug', $category->slug)); ?>" role="button" id="<?php echo e($category->slug); ?>" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
	<?php echo e($category->name); ?>

	</a>
	<div class="dropdown-menu" aria-labelledby="<?php echo e($category->slug); ?>">
	<?php $__currentLoopData = $subs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<a class="dropdown-item" href="<?php echo e(route('front.category.slug', $sub->slug)); ?>"><?php echo e($sub->name); ?></a> 
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>