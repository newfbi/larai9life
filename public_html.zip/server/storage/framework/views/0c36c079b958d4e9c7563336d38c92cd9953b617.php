<ul class="list-unstyled" style="padding-left: 25px">
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <div class="checkbox">
                <label>
                    <input
                            type="checkbox"
                            <?php if(isset($selectedIds) && in_array($category->id, $selectedIds)): ?>checked="checked" <?php endif; ?>
                            name="categories[]"
                            value="<?php echo e($category->id); ?>">
                            <?php echo e($category->name); ?>

                </label>
            </div>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>