

<?php $__env->startSection('og'); ?>
    <meta property="og:type" content="home"/>
    <meta property="og:title" content="<?php echo e(config('app.name')); ?>"/>
    <meta property="og:description" content="<?php echo e(config('app.name')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 
    <?php echo $__env->make('layouts.front.home-slider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <hr>
    <?php if(!$featured->products->isEmpty()): ?>
        <div class="container">
            <div class="section-title b100">
                <h2>produtos em destaque</h2>
            </div>
            <?php echo $__env->make('front.products.product-list', ['products' => $featured->products], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div id="browse-all-btn"> <a class="btn btn-default browse-all-btn" href="<?php echo e(route('front.category.slug', $featured->slug)); ?>" role="button">Buscar todos itens</a></div>
        </div>
    <?php endif; ?>
    <hr/> 
    <hr>
    <?php if(!$newArrivals->products->isEmpty()): ?>
        <div class="container">
            <div class="section-title b100">
                <h2>Novidades - Lançamentos</h2>
            </div>
            <?php echo $__env->make('front.products.product-list', ['products' => $newArrivals->products], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div id="browse-all-btn"> <a class="btn btn-default browse-all-btn" href="<?php echo e(route('front.category.slug', $newArrivals->slug)); ?>" role="button">Buscar todos itens</a></div>
        </div>
    <?php endif; ?>
    </hr>
    <?php echo $__env->make('mailchimp::mailchimp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>