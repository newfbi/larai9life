<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
    <?php echo $__env->make('layouts.errors-and-messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Default box -->
        <div class="box">
            <div class="box-header">
                <div class="row">
                    <div class="col-md-6">
                        <h2>
                            <a href="<?php echo e(route('admin.customers.show', $customer->id)); ?>">Nome: <?php echo e($customer->name); ?></a> <br />
                            <small>Email: <?php echo e($customer->email); ?></small> <br />
                            <small>Referencia do pedido: <strong><?php echo e($order->reference); ?></strong></small>
                        </h2>
                    </div>
                    <div class="col-md-3 col-md-offset-3">
                        <a href="<?php echo e(route('admin.orders.invoice.generate', $order['id'])); ?>" class="btn btn-primary btn-block">Download de Pedido</a>
                    </div>
                </div>                
                <div class="col-md-2">
                    <h2><a href="<?php echo e(route('admin.orderupdate', $order['id'])); ?>" class="btn btn-primary btn-block">Editar pedido</a></h2>
                </div>
            </div>
        </div>
        <div class="box">
            <div class="box-body">
                <h3> <i class="fa fa-shopping-bag"></i> Informações do Pedido</h3>
                <table class="table">
                    <thead>
                        <tr>
                            <td class="col-md-3">Data</td>
                            <td class="col-md-3">Cliente</td>
                            <td class="col-md-3">Pagamento</td>
                            <td class="col-md-3">Status</td>
                        </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td><?php echo e(date('M d, Y h:i a', strtotime($order['created_at']))); ?></td>
                        <td><a href="<?php echo e(route('admin.customers.show', $customer->id)); ?>"><?php echo e($customer->name); ?></a></td>
                        <td><strong><?php echo e($order['payment']); ?></strong></td>
                        <?php if($order->order_status_id == 1): ?>
                        <td><button type="button" class="btn btn-primary btn-block"><?php echo e($currentStatus->name); ?></button></td>
                        <?php endif; ?>
                        <?php if($order->order_status_id == 2): ?>
                        <td><button type="button" class="btn btn-info btn-block"><?php echo e($currentStatus->name); ?></button></td>
                        <?php endif; ?>
                        <?php if($order->order_status_id == 3): ?>
                        <td><button type="button" class="btn btn-danger btn-block"><?php echo e($currentStatus->name); ?></button></td>
                        <?php endif; ?>
                        <?php if($order->order_status_id == 4): ?>
                        <td><button type="button" class="btn btn-success btn-block"><?php echo e($currentStatus->name); ?></button></td>
                        <?php endif; ?>
                    </tr>
                    </tbody>
                    <tbody>
                    <tr>
                        <td></td>
                        <td></td>
                        <td class="bg-warning">Subtotal</td>
                        <td class="bg-warning"><?php echo e($order['total_products']); ?></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td class="bg-warning">Taxa</td>
                        <td class="bg-warning"><?php echo e($order['tax']); ?></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td class="bg-warning">Disconto</td>
                        <td class="bg-warning"><?php echo e($order['discounts']); ?></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td class="bg-success text-bold">Total do Pedido</td>
                        <td class="bg-success text-bold"><?php echo e($order['total']); ?></td>
                    </tr>
                    <?php if($order['total_paid'] != $order['total']): ?>
                        <tr>
                            <td></td>
                            <td></td>
                            <td class="bg-danger text-bold">Total paid</td>
                            <td class="bg-danger text-bold"><?php echo e($order['total_paid']); ?></td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <!-- /.box-body -->
        </div>
        <?php if($order): ?>
            <?php if($order->total != $order->total_paid): ?>
                <p class="alert alert-danger">
                    Ooops, há discrepância no valor total do pedido e no valor pago. <br />
                    Valor total do pedito: <strong><?php echo e(config('cart.currency')); ?> <?php echo e($order->total); ?></strong> <br>
                    Valor total pago <strong><?php echo e(config('cart.currency')); ?> <?php echo e($order->total_paid); ?></strong>
                </p>

            <?php endif; ?>
            <div class="box">
                <?php if(!$items->isEmpty()): ?>
                    <div class="box-body">
                        <h3> <i class="fa fa-gift"></i> Items</h3>
                        <table class="table">
                            <thead>
                            <th class="col-md-2">Referencia</th>
                            <th class="col-md-2">Nome</th>
                            <th class="col-md-2">Descrição</th>
                            <th class="col-md-2">Quantidade</th>
                            <th class="col-md-2">Preço</th>
                            <th class="col-md-2">Status</th>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->sku); ?></td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td><?php echo $item->description; ?></td>
                                    <td><?php echo e($item->pivot->quantity); ?></td>
                                    <td><?php echo e($item->price); ?></td>
                                    <td><?php echo $__env->make('layouts.status', ['status' => $item->status], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
                <div class="box-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h3> <i class="fa fa-truck"></i> Entrega</h3>
                            <table class="table">
                                <thead>
                                    <th class="col-md-3">Tipo de Entrega</th>
                                    <th class="col-md-4">Descrição</th>
                                    <th class="col-md-5">Taxa</th>
                                </thead>
                                <tbody>
                                <tr>
                                    <td><?php echo e($order->courier->name); ?></td>
                                    <td><?php echo e($order->courier->description); ?></td>
                                    <td><?php echo e($order->courier->cost); ?></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <h4> <i class="fa fa-map-marker"></i> Endereço</h4>
                            <table class="table">
                                <thead>
                                    <th>Endereço</th>
                                    <th>Numero</th>
                                    <th>Cidade</th>
                                    <th>Telefone</th>
                                    <th>CEP</th>
                                </thead>
                                <tbody>
                                <tr>
                                    <td><?php echo e($order->address->alias); ?></td>
                                    <td><?php echo e($order->address->address_1); ?></td>
                                    <td><?php echo e($order->address->city->name); ?></td>
                                    <td><?php echo e($order->address->phone); ?></td>
                                    <td><?php echo e($order->address->zip); ?></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.box -->
            <div class="box-footer">
                <a href="<?php echo e(route('admin.orders.index')); ?>" class="btn btn-default">Voltar</a>
            </div>
        <?php endif; ?>

    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>