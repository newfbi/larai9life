<?php $__env->startSection('content'); ?>
        <div class="container product-in-cart-list">
            <?php if(!$cartItems->isEmpty()): ?>
                <div class="row">
                    <div class="col-md-12">
                        <ol class="breadcrumb">
                            <li><a href="<?php echo e(route('home')); ?>"> <i class="fa fa-home"></i> Home</a></li>
                            <li class="active">Carrinho</li>
                        </ol>
                    </div>
                    <div class="col-md-12 content">
                        <div class="box-body">
                            <?php echo $__env->make('layouts.errors-and-messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                        <h3><i class="fa fa-cart-plus"></i> Shopping Cart</h3>
                        <table class="table table-striped">
                            <thead>
                                <th class="col-md-2 col-lg-2">Produto</th>
                                <th class="col-md-2 col-lg-5">Nome</th>
                                <th class="col-md-2 col-lg-2">Quantidade</th>
                                <th class="col-md-2 col-lg-1"></th>
                                <th class="col-md-2 col-lg-2">Preço</th>
                            </thead>
                            <tfoot>
                            <tr>
                                <td class="bg-warning">Subtotal</td>
                                <td class="bg-warning"></td>
                                <td class="bg-warning"></td>
                                <td class="bg-warning"></td>
                                <td class="bg-warning"><?php echo e(config('cart.currency')); ?> <?php echo e($subtotal); ?></td>
                            </tr>
                            <?php if(isset($shippingFee) && $shippingFee != 0): ?>
                            <tr>
                                <td class="bg-warning">Entrega</td>
                                <td class="bg-warning"></td>
                                <td class="bg-warning"></td>
                                <td class="bg-warning"></td>
                                <td class="bg-warning"><?php echo e(config('cart.currency')); ?> <?php echo e($shippingFee); ?></td>
                            </tr>
                            <?php endif; ?>
                            <tr>
                                <td class="bg-warning">Taxa</td>
                                <td class="bg-warning"></td>
                                <td class="bg-warning"></td>
                                <td class="bg-warning"></td>
                                <td class="bg-warning"><?php echo e(config('cart.currency')); ?> <?php echo e(number_format($tax, 2)); ?></td>
                            </tr>
                            <tr>
                                <td class="bg-success">Total</td>
                                <td class="bg-success"></td>
                                <td class="bg-success"></td>
                                <td class="bg-success"></td>
                                <td class="bg-success"><?php echo e(config('cart.currency')); ?> <?php echo e($total); ?></td>
                            </tr>
                            </tfoot>
                            <tbody>
                            <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <a href="<?php echo e(route('front.get.product', [$cartItem->product->slug])); ?>" class="hover-border">
                                            <?php if(isset($cartItem->cover)): ?>
                                                <img src="<?php echo e(asset("storage/$cartItem->cover")); ?>" alt="<?php echo e($cartItem->name); ?>" class="img-responsive img-thumbnail">
                                            <?php else: ?>
                                                <img src="https://placehold.it/120x120" alt="" class="img-responsive img-thumbnail">
                                            <?php endif; ?>
                                        </a>
                                    </td>
                                    <td>
                                        <h3><?php echo e($cartItem->name); ?></h3>
                                        <?php if(isset($cartItem->options)): ?>
                                            <?php $__currentLoopData = $cartItem->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <span class="label label-primary"><?php echo e($key); ?> : <?php echo e($option); ?></span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        <div class="product-description">
                                            <?php echo $cartItem->product->description; ?>

                                        </div>
                                    </td>
                                    <td>
                                        <form action="<?php echo e(route('cart.update', $cartItem->rowId)); ?>" class="form-inline" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="_method" value="put">
                                            <div class="input-group">
                                                <input  onkeydown="return false" required type="number" name="quantity" value="<?php echo e($cartItem->qty); ?>" min="1" max="99" class="form-control"/>
                                                <span class="input-group-btn"><button class="btn btn-default">Atualizar</button></span>
                                            </div>
                                        </form>
                                    </td>
                                    <td>
                                        <form action="<?php echo e(route('cart.destroy', $cartItem->rowId)); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="_method" value="delete">
                                            <button onclick="return confirm('Are you sure?')" class="btn btn-danger"><i class="fa fa-times"></i></button>
                                        </form>
                                    </td>
                                    <td><?php echo e(config('cart.currency')); ?> <?php echo e(number_format($cartItem->price, 2)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <hr>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="btn-group pull-right">
                                    <a href="<?php echo e(route('home')); ?>" class="btn btn-default">Continar Escolhendo</a>
                                    <a href="<?php echo e(route('checkout.index')); ?>" class="btn btn-primary">Finalizar Pedido</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="row">
                    <div class="col-md-12">
                        <p class="alert alert-warning">Nenhum produto no carrinho ainda. <a href="<?php echo e(route('home')); ?>">Escolha agora!</a></p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <style type="text/css">
        .product-description {
            padding: 10px 0;
        }
        .product-description p {
            line-height: 18px;
            font-size: 14px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>