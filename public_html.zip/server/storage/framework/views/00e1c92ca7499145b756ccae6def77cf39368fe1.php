<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">

        <?php echo $__env->make('layouts.errors-and-messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <!-- Default box -->
        <?php if($orderStatuses): ?>
        <div class="box">
            <div class="box-body">
                <h2>Order Status</h2>
                <table class="table">
                    <thead>
                        <tr>
                            <td class="col-md-4">Name</td>
                            <td class="col-md-4">Color</td>
                            <td class="col-md-4">Actions</td>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $orderStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($status->name); ?></td>
                            <td><button class="btn" style="background-color: <?php echo e($status->color); ?>"><i class="fa fa-check" style="color: #ffffff"></i></button></td>
                            <td>
                                <form action="<?php echo e(route('admin.order-statuses.destroy', $status->id)); ?>" method="post" class="form-horizontal">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="_method" value="delete">
                                    <div class="btn-group">
                                        <a href="<?php echo e(route('admin.order-statuses.edit', $status->id)); ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> Edit</a>
                                        <button onclick="return confirm('Are you sure?')" type="submit" class="btn btn-danger btn-sm"><i class="fa fa-times"></i> Delete</button>
                                    </div>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->
        <?php endif; ?>

    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>