<?php $__env->startSection('content'); ?>
    <div class="container product-in-cart-list">
        <?php if(!$products->isEmpty()): ?>
            <div class="row">
                <div class="col-md-12">
                    <ol class="breadcrumb">
                        <li><a href="<?php echo e(route('home')); ?>"> <i class="fa fa-home"></i> Inicio</a></li>
                        <li class="active">Carrinho</li>
                    </ol>
                </div>
                <div class="col-md-12 content">
                    <div class="box-body">
                        <?php echo $__env->make('layouts.errors-and-messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </div>
                    <?php if(count($addresses) > 0): ?>
                        <div class="row">
                            <div class="col-md-12">
                                <?php echo $__env->make('front.products.product-list-table', compact('products'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <table class="table table-striped">
                                    <thead>
                                        <th>Endereço</th>
                                        <th>Número</th>
                                        <th>Seu endereço</th>
                                        <th>Endereço de Entrega</th>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($address->alias); ?></td>
                                                <td>
                                                    <?php echo e($address->address_1); ?> <?php echo e($address->address_2); ?> <br />
                                                    <?php if(!is_null($address->province) || !is_null($address->city)): ?>
                                                        <?php echo e($address->city->name); ?> <?php echo e($address->province->name); ?> <br />
                                                    <?php endif; ?>
                                                    <?php echo e($address->country->name); ?> <?php echo e($address->zip); ?>

                                                </td>
                                                <td>
                                                    <label class="col-md-6 col-md-offset-3">
                                                    <input
                                                        type="radio"
                                                        value="<?php echo e($address->id); ?>"
                                                        name="billing_address"
                                                        <?php if(old('') == $address->id): ?> checked="checked"  <?php endif; ?>>
                                                    </label>
                                                </td>
                                                <td>
                                                    <?php if($key === 0): ?>
                                                        <label for="sameDeliveryAddress">
                                                            <input type="checkbox" id="sameDeliveryAddress" checked="checked"> O mesmo que Faturamento
                                                        </label>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <tbody style="display: none" id="sameDeliveryAddressRow">
                                        <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($address->alias); ?></td>
                                                <td>
                                                    <?php echo e($address->address_1); ?> <?php echo e($address->address_2); ?> <br />
                                                    <?php if(!is_null($address->province) || !is_null($address->city)): ?>
                                                        <?php echo e($address->city->name); ?> <?php echo e($address->province->name); ?> <br />
                                                    <?php endif; ?>
                                                    <?php echo e($address->country->name); ?> <?php echo e($address->zip); ?>

                                                </td>
                                                <td></td>
                                                <td>
                                                    <label class="col-md-6 col-md-offset-3">
                                                        <input
                                                            type="radio"
                                                            value="<?php echo e($address->id); ?>"
                                                            name="delivery_address"
                                                            <?php if(old('') == $address->id): ?> checked="checked"  <?php endif; ?>>
                                                    </label>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="col-md-6">
                                <?php if(!$couriers->isEmpty()): ?>
                                    <table class="table table-striped">
                                        <thead>
                                        <th>Nome</th>
                                        <th>Valor</th>
                                        <th>Retirar com o Vendedor</th>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $couriers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($courier->name); ?></td>
                                                <td><?php echo e(config('cart.currency')); ?> <?php echo e($courier->cost); ?></td>
                                                <td>
                                                    <label class="col-md-6 col-md-offset-3">
                                                        <input
                                                            data-cost="<?php echo e($courier->cost); ?>"
                                                            type="radio"
                                                            name="courier"
                                                            value="<?php echo e($courier->id); ?>"
                                                            <?php if(old('courier') == $courier->id): ?> checked="checked"  <?php endif; ?>>
                                                    </label>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                <?php else: ?>
                                    <p class="alert alert-danger">Sem encomendas</p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <?php if(isset($payments) && !empty($payments)): ?>
                                    <table class="table table-striped">
                                        <thead>
                                        <th class="col-md-4">Name</th>
                                        <th class="col-md-4">Description</th>
                                        <th class="col-md-4 text-right">Choose payment</th>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo $__env->make('layouts.front.payment-options', compact('payment', 'total'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                <?php else: ?>
                                    <p class="alert alert-danger">Nenhum metodo de pagamento</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php else: ?>
                        <p class="alert alert-danger"><a href="<?php echo e(route('customer.address.create', [$customer->id])); ?>">Nenhum endereço encontrado. Você precisa criar um endereço primeiro aqui.</a></p>
                    <?php endif; ?>
                </div>
            </div>
        <?php else: ?>
            <div class="row">
                <div class="col-md-12">
                    <p class="alert alert-warning">Nenhum produto no carrinho ainda. <a href="<?php echo e(route('home')); ?>">Compre agora!</a></p>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>