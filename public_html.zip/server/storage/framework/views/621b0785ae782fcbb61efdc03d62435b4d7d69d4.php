<?php if(!empty($products) && !collect($products)->isEmpty()): ?>
    <ul class="row text-center list-unstyled">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <li class="col-md-3 col-sm-6 col-xs-12 product-list">
                <div class="single-product">
                    <div class="product">
                        <div class="product-overlay">
                            <div class="vcenter">
                                <div class="centrize">
                                    <ul class="list-unstyled list-group">
                                        <li>
                                            <form action="<?php echo e(route('cart.store')); ?>" class="form-inline" method="post">
                                                <?php echo e(csrf_field()); ?>

                                                <input type="hidden" name="quantity" value="1" />
                                                <input type="hidden" name="product" value="<?php echo e($product->id); ?>">
                                                <button id="add-to-cart-btn" type="submit" class="btn btn-warning" data-toggle="modal" data-target="#cart-modal"> <i class="fa fa-cart-plus"></i> Por no Carrinho</button>
                                            </form>
                                        </li>
                                        <li>  <a class="btn btn-default product-btn" href="<?php echo e(route('front.get.product', str_slug($product->slug))); ?>"> <i class="fa fa-link"></i>Viualizar</a> </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <?php if(isset($product->cover)): ?>
                            <img src="<?php echo e(asset("storage/$product->cover")); ?>" alt="<?php echo e($product->name); ?>" class="img-bordered img-responsive">
                        <?php else: ?>
                            <img src="https://placehold.it/263x330" alt="<?php echo e($product->name); ?>" class="img-bordered img-responsive" />
                        <?php endif; ?>
                    </div>

                    <div class="product-text">
                        <h4><?php echo e($product->name); ?></h4>
                        <p><?php echo e(config('cart.currency')); ?> <?php echo e(number_format($product->price, 2)); ?></p>
                    </div>
                    <!-- Modal -->
                    <div class="modal fade" id="myModal_<?php echo e($product->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <?php echo $__env->make('layouts.front.product', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if($products instanceof \Illuminate\Contracts\Pagination\LengthAwarePaginator): ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="pull-left"><?php echo e($products->links()); ?></div>
                </div>
            </div>
        <?php endif; ?>
    </ul>
<?php else: ?>
    <p class="alert alert-warning"></p>
<?php endif; ?>