<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
    <?php echo $__env->make('layouts.errors-and-messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Default box -->
        <?php if($addresses): ?>
            <div class="box">
                <div class="box-body">
                    <h2>Addresses</h2>
                    <?php echo $__env->make('layouts.search', ['route' => route('admin.addresses.index')], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <td class="col-md-1">Alias</td>
                                <td class="col-md-2">Address 1</td>
                                <td class="col-md-1">Country</td>
                                <td class="col-md-2">Province</td>
                                <td class="col-md-1">City</td>
                                <td class="col-md-1">Zip Code</td>
                                <td class="col-md-1">Status</td>
                                <td class="col-md-3">Actions</td>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><a href="<?php echo e(route('admin.customers.show', [$address->customer_id])); ?>"><?php echo e($address->alias); ?></a></td>
                                <td><?php echo e($address->address_1); ?></td>
                                <td><?php echo e($address->country); ?></td>
                                <td><?php echo e($address->province); ?></td>
                                <td><?php echo e($address->city); ?></td>
                                <td><?php echo e($address->zip); ?></td>
                                <td><?php echo $__env->make('layouts.status', ['status' => $address->status], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                                <td>
                                    <form action="<?php echo e(route('admin.addresses.destroy', $address->id)); ?>" method="post" class="form-horizontal">
                                        <?php echo e(csrf_field()); ?>

                                        <input type="hidden" name="_method" value="delete">
                                        <div class="btn-group">
                                            <a href="<?php echo e(route('admin.addresses.edit', $address->id)); ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> Edit</a>
                                            <button onclick="return confirm('Are you sure?')" type="submit" class="btn btn-danger btn-sm"><i class="fa fa-times"></i> Delete</button>
                                        </div>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php if($addresses instanceof \Illuminate\Contracts\Pagination\LengthAwarePaginator): ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="pull-left"><?php echo e($addresses->links()); ?></div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        <?php else: ?>
            <div class="box">
                <div class="box-body"><p class="alert alert-warning">No addresses found.</p></div>
            </div>
        <?php endif; ?>
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>