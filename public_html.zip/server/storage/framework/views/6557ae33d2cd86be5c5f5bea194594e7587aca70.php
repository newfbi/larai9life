<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="container content">
        <div class="row">
            <div class="col-md-12">
                <h2> <i class="fa fa-home"></i>Minha Conta</h2>
                <hr>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div>
                    <!-- Nav tabs -->
                    <ul class="nav nav-tabs" role="tablist">
                        <li role="presentation"><a href="#orders" aria-controls="orders" role="tab" data-toggle="tab">Pedidos</a></li>
                        <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Perfil</a></li>
                        <li role="presentation"><a href="#address" aria-controls="address" role="tab" data-toggle="tab">Endereços</a></li>
                    </ul>

                    <!-- Tab panes -->
                    <div class="tab-content customer-order-list">
                        <div role="tabpanel" class="tab-pane" id="profile">
                            <?php echo e($customer->name); ?> <br /><small><?php echo e($customer->email); ?></small>
                        </div>
                        <div role="tabpanel" class="tab-pane  active" id="orders">
                            <table class="table">
                                <tbody>
                                <tr>
                                    <td class="col-md-3">Data</td>
                                    <td class="col-md-2">Correio</td>
                                    <td class="col-md-2">Total</td>
                                    <td class="col-md-2">Status</td>
                                </tr>
                                </tbody>
                                <tbody>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <a href="<?php echo e(route('orders.show', $order['id'])); ?>"><?php echo e(date('M d, Y h:i a', strtotime($order['created_at']))); ?></a>
                                            <!-- Button trigger modal -->
                                        </td>
                                        <td><?php echo e($order['courier']->name); ?></td>
                                        <td><span class="label <?php if($order['total'] != $order['total_paid']): ?> label-danger <?php else: ?> label-success <?php endif; ?>"><?php echo e(config('cart.currency')); ?> <?php echo e($order['total']); ?></span></td>
                                        <td><p class="text-center" style="color: #ffffff; background-color: <?php echo e($order['status']->color); ?>"><?php echo e($order['status']->name); ?></p></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php echo e($orders->links()); ?>

                        </div>
                        <div role="tabpanel" class="tab-pane" id="address">
                            <div class="row">
                                <div class="col-md-6">
                                    <a href="<?php echo e(route('address.create')); ?>" class="btn btn-primary">Criar novo Endereço</a>
                                </div>
                            </div>
                            <table class="table">
                                <thead>
                                    <th>Rua</th>
                                    <th>Numero</th>
                                    <th>Complemento</th>
                                    <th>Cidade</th>
                                    <th>CEP</th>
                                    <th>Telefone</th>
                                    <th>Status</th>
                                </thead>
                                <tbody>                                
                                <?php if($addresses == null): ?>
                                <?php else: ?>
                                <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($address->alias); ?></td>
                                        <td><?php echo e($address->address_1); ?></td>
                                        <td><?php echo e($address->address_2); ?></td>
                                        <td><?php echo e($city); ?></td>
                                        <td><?php echo e($address->zip); ?></td>
                                        <td><?php echo e($address->phone); ?></td>
                                        <td>
                                            <form action="<?php echo e(route('address.destroy', $address->id)); ?>" method="post" class="form-horizontal">
                                                <?php echo e(csrf_field()); ?>

                                                <input type="hidden" name="_method" value="delete">
                                                <div class="btn-group">
                                                    <a href="<?php echo e(route('address.edit', $address->id)); ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> Editar</a>
                                                    <button onclick="return confirm('Are you sure?')" type="submit" class="btn btn-danger btn-sm"><i class="fa fa-times"></i> Deletar</button>
                                                </div>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>