<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
    <?php echo $__env->make('layouts.errors-and-messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Default box -->
        <div class="box">
            <div class="box-body">
                <h2>Addresses</h2>
                <table class="table">
                    <tbody>
                    <tr>
                        <td class="col-md-1">Alias</td>
                        <td class="col-md-2">Address 1</td>
                        <td class="col-md-2">Address 2</td>
                        <td class="col-md-2">City</td>
                        <td class="col-md-2">Country</td>
                        <td class="col-md-2">Zip</td>
                        <td class="col-md-1">Status</td>
                    </tr>
                    </tbody>
                    <tbody>
                    <tr>
                        <td><?php echo e($address->alias); ?></td>
                        <td><?php echo e($address->address_1); ?></td>
                        <td><?php echo e($address->address_2); ?></td>
                        <td>
                            <?php if(isset($address->city)): ?>
                                <?php echo e($address->city->name); ?>

                            <?php endif; ?>
                        </td>
                        <td><?php echo e($address->country->name); ?></td>
                        <td><?php echo e($address->zip); ?></td>
                        <td><?php echo $__env->make('layouts.status', ['status' => $address->status], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                    </tr>
                    </tbody>
                </table>
            </div>
            <!-- /.box-body -->
            <div class="box-footer">
                <div class="btn-group">
                    <a href="<?php echo e(route('accounts')); ?>" class="btn btn-default btn-sm">Back</a>
                </div>
            </div>
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>