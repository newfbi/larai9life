<div class="dropdown">
    <a <?php if(request()->segment(2) == $category->slug): ?> class="active" <?php endif; ?> href="<?php echo e(route('front.category.slug', $category->slug)); ?>" class="dropdown-toggle" id="<?php echo e($category->slug); ?>" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true"><?php echo e($category->name); ?> <span class="caret"></span></a>
    <ul class="dropdown-menu" aria-labelledby="<?php echo e($category->slug); ?>">
        <?php $__currentLoopData = $subs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(route('front.category.slug', $sub->slug)); ?>"><?php echo e($sub->name); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>