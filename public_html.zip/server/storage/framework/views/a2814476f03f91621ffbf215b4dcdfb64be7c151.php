

<?php $__env->startSection('og'); ?>
    <meta property="og:type" content="product"/>
    <meta property="og:title" content="<?php echo e($product->name); ?>"/>
    <meta property="og:description" content="<?php echo e(strip_tags($product->description)); ?>"/>
    <?php if(!is_null($product->cover)): ?>
        <meta property="og:image" content="<?php echo e(asset("storage/$product->cover")); ?>"/>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h2 class="modal-title" id="myModalLabel">I9Infinity</h2>
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
          </div>
          <div class="modal-body">
            <p> Sejam bem vindos.<br>
                Não efetuamos vendas online, temos apenas um catalogo de produtos, que podem ser selecionados e reservados para serem
                retirados direto com um representante ou vendedor da empresa I9life.
            </p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
          </div>
        </div>
      </div>
    </div>
    <div class="container product">
        <div class="row">
            <div class="col-md-12">
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(route('home')); ?>"> <i class="fa fa-home"></i> Home</a></li>
                    <?php if(isset($category)): ?>
                    <li><a href="<?php echo e(route('front.category.slug', $category->slug)); ?>"><?php echo e($category->name); ?></a></li>
                    <?php endif; ?>
                    <li class="active">Product</li>
                </ol>
            </div>
        </div>
        <?php echo $__env->make('layouts.front.product', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/front.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            var productPane = document.querySelector('.product-cover');
            var paneContainer = document.querySelector('.product-cover-wrap');

            new Drift(productPane, {
                paneContainer: paneContainer,
                inlinePane: false
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>