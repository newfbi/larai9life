<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">

    <?php echo $__env->make('layouts.errors-and-messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Default box -->
        <?php if($couriers): ?>
            <div class="box">
                <div class="box-body">
                    <h2> <i class="fa fa-truck"></i> Couriers</h2>
                    <table class="table">
                        <thead>
                            <tr>
                                <td class="col-md-2">Name</td>
                                <td class="col-md-2">Description</td>
                                <td class="col-md-2">URL</td>
                                <td class="col-md-1">Is Free?</td>
                                <td class="col-md-1">Cost</td>
                                <td class="col-md-1">Status</td>
                                <td class="col-md-3">Actions</td>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $couriers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $courier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($courier->name); ?></td>
                                <td><?php echo e(str_limit($courier->description, 100, ' ...')); ?></td>
                                <td><?php echo e($courier->url); ?></td>
                                <td>
                                    <?php echo $__env->make('layouts.status', ['status' => $courier->is_free], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                </td>
                                <td>
                                    <?php echo e(config('cart.currency')); ?> <?php echo e($courier->cost); ?>

                                </td>
                                <td><?php echo $__env->make('layouts.status', ['status' => $courier->status], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                                <td>
                                    <form action="<?php echo e(route('admin.couriers.destroy', $courier->id)); ?>" method="post" class="form-horizontal">
                                        <?php echo e(csrf_field()); ?>

                                        <input type="hidden" name="_method" value="delete">
                                        <div class="btn-group">
                                            <a href="<?php echo e(route('admin.couriers.edit', $courier->id)); ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> Edit</a>
                                            <button onclick="return confirm('Are you sure?')" type="submit" class="btn btn-danger btn-sm"><i class="fa fa-times"></i> Delete</button>
                                        </div>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        <?php endif; ?>

    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>