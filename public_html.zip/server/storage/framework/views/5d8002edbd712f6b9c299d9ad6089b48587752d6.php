<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
    <?php echo $__env->make('layouts.errors-and-messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- Default box -->
        <?php if($categories): ?>
            <div class="box">
                <div class="box-body">
                    <h2>Categorias</h2>
                    <table class="table">
                        <thead>
                            <tr>
                                <td class="col-md-3">Nome</td>
                                <td class="col-md-3">Imagem</td>
                                <td class="col-md-3">Status</td>
                                <td class="col-md-3">Ações</td>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <a href="<?php echo e(route('admin.categories.show', $category->id)); ?>"><?php echo e($category->name); ?></a></td>
                                <td>
                                    <?php if(isset($category->cover)): ?>
                                        <img src="<?php echo e(asset("storage/$category->cover")); ?>" alt="" class="img-responsive">
                                    <?php endif; ?>
                                </td>
                                <td><?php echo $__env->make('layouts.status', ['status' => $category->status], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></td>
                                <td>
                                    <form action="<?php echo e(route('admin.categories.destroy', $category->id)); ?>" method="post" class="form-horizontal">
                                        <?php echo e(csrf_field()); ?>

                                        <input type="hidden" name="_method" value="delete">
                                        <div class="btn-group">
                                            <a href="<?php echo e(route('admin.categories.edit', $category->id)); ?>" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> Editar</a>
                                            <button onclick="return confirm('Are you sure?')" type="submit" class="btn btn-danger btn-sm"><i class="fa fa-times"></i> Deletar</button>
                                        </div>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($categories->links()); ?>

                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
        <?php endif; ?>

    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>