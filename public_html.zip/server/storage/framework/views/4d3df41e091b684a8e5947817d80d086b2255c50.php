<?php if(!$products->isEmpty()): ?>
    <table class="table table-striped">
        <thead>
        <th class="col-md-2 col-lg-2">Cover</th>
        <th class="col-md-2 col-lg-5">Name</th>
        <th class="col-md-2 col-lg-2">Quantity</th>
        <th class="col-md-2 col-lg-1"></th>
        <th class="col-md-2 col-lg-2">Price</th>
        </thead>
        <tfoot>
        <tr>
            <td class="bg-warning">Subtotal</td>
            <td class="bg-warning"></td>
            <td class="bg-warning"></td>
            <td class="bg-warning"></td>
            <td class="bg-warning"><?php echo e(config('cart.currency')); ?> <?php echo e($subtotal); ?></td>
        </tr>
        <tr>
            <td class="bg-warning">Shipping</td>
            <td class="bg-warning"></td>
            <td class="bg-warning"></td>
            <td class="bg-warning"></td>
            <td class="bg-warning"><?php echo e(config('cart.currency')); ?> <span id="shippingFee"><?php echo e($shippingFee); ?></span></td>
        </tr>
        <tr>
            <td class="bg-warning">Tax</td>
            <td class="bg-warning"></td>
            <td class="bg-warning"></td>
            <td class="bg-warning"></td>
            <td class="bg-warning"><?php echo e(config('cart.currency')); ?> <?php echo e(number_format($tax, 2)); ?></td>
        </tr>
        <tr>
            <td class="bg-success">Total</td>
            <td class="bg-success"></td>
            <td class="bg-success"></td>
            <td class="bg-success"></td>
            <td class="bg-success"><?php echo e(config('cart.currency')); ?> <span id="total" data-total="<?php echo e($total); ?>"><?php echo e($total); ?></span></td>
        </tr>
        </tfoot>
        <tbody>
        <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <a href="<?php echo e(route('front.get.product', [$cartItem->product->slug])); ?>" class="hover-border">
                        <?php if(isset($cartItem->cover)): ?>
                            <img src="<?php echo e(asset("storage/$cartItem->cover")); ?>" alt="<?php echo e($cartItem->name); ?>" class="img-responsive img-thumbnail">
                        <?php else: ?>
                            <img src="https://placehold.it/120x120" alt="" class="img-responsive img-thumbnail">
                        <?php endif; ?>
                    </a>
                </td>
                <td>
                    <h3><?php echo e($cartItem->name); ?></h3>
                    <?php if(isset($cartItem->options)): ?>
                        <?php $__currentLoopData = $cartItem->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="label label-primary"><?php echo e($key); ?> : <?php echo e($option); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <div class="product-description">
                        <?php echo $cartItem->product->description; ?>

                    </div>
                </td>
                <td>
                    <form action="<?php echo e(route('cart.update', $cartItem->rowId)); ?>" class="form-inline" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="_method" value="put">
                        <div class="input-group">
                            <input type="text" name="quantity" value="<?php echo e($cartItem->qty); ?>" class="form-control" />
                            <span class="input-group-btn"><button class="btn btn-default">Update</button></span>
                        </div>
                    </form>
                </td>
                <td>
                    <form action="<?php echo e(route('cart.destroy', $cartItem->rowId)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="_method" value="delete">
                        <button onclick="return confirm('Are you sure?')" class="btn btn-danger"><i class="fa fa-times"></i></button>
                    </form>
                </td>
                <td><?php echo e(config('cart.currency')); ?> <?php echo e(number_format($cartItem->price, 2)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php endif; ?>