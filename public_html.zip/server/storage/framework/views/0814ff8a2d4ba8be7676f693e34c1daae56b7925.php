<!-- Collect the nav links, forms, and other content for toggling -->
<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
    <?php echo $__env->make('layouts.front.category-nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <ul class="nav navbar-nav navbar-right">
        <?php if(auth()->check()): ?>
            <li class="visible-xs"><a href="<?php echo e(route('accounts')); ?>"><i class="fa fa-home"></i> Minha Conta</a></li>
            <li class="visible-xs"><a href="<?php echo e(route('logout')); ?>"><i class="fa fa-sign-out"></i> Sair</a></li>
        <?php else: ?>
            <li class="visible-xs"><a href="<?php echo e(route('login')); ?>"> <i class="fa fa-lock"></i> Login</a></li>
            <li class="visible-xs"><a href="<?php echo e(route('register')); ?>"> <i class="fa fa-sign-in"></i> Registrar</a></li>
        <?php endif; ?>
        <li id="cart" class="menubar-cart visible-xs">
            <a href="<?php echo e(route('cart.index')); ?>" title="View Cart" class="awemenu-icon menu-shopping-cart">
                <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                <span class="cart-number"><?php echo e($cartCount); ?></span>
            </a>
        </li>
    </ul>
    <ul class="nav navbar-nav navbar-right">
        <?php if(auth()->check()): ?>
            <li><a href="<?php echo e(route('accounts')); ?>"><i class="fa fa-home"></i> Minha Conta</a></li>
            <li><a href="<?php echo e(route('logout')); ?>"><i class="fa fa-sign-out"></i> Sair</a></li>
        <?php else: ?>
            <li><a href="<?php echo e(route('login')); ?>"> <i class="fa fa-lock"></i> Login</a></li>
            <li><a href="<?php echo e(route('register')); ?>"> <i class="fa fa-sign-in"></i> Registrar</a></li>
        <?php endif; ?>
        <li id="cart" class="menubar-cart">
            <a href="<?php echo e(route('cart.index')); ?>" title="Ver Carrinho" class="awemenu-icon menu-shopping-cart">
                <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                <span class="cart-number"><?php echo e($cartCount); ?></span>
            </a>
        </li>
    </ul>
</div><!-- /.navbar-collapse -->