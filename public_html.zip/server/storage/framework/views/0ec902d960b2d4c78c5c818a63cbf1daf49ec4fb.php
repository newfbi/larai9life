<?php $__currentLoopData = $subs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(route('front.category.slug', $category->slug)); ?>"><?php echo e($category->name); ?></a>
    <ul class="list-unstyled sidebar-category-sub">
        <li <?php if(request()->segment(2) == $sub->slug): ?> class="active" <?php endif; ?> ><a href="<?php echo e(route('front.category.slug', $sub->slug)); ?>"><?php echo e($sub->name); ?></a></li>
    </ul>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>