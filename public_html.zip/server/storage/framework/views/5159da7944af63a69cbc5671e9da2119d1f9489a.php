<footer class="footer-section footer">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">

                <ul class="footer-menu">
                    <li> <a href="<?php echo e(route('accounts')); ?>">Sua conta</a>  </li>
                    <li> <a href="">Contato</a>  </li>
                    <li> <a href="">Termos de uso</a>  </li>
                </ul>

                <ul class="footer-social">
                    <li> <a href=""> <i class="fa fa-facebook" aria-hidden="true"></i>  </a> </li>
                    <li> <a href=""> <i class="fa fa-twitter" aria-hidden="true"></i>   </a> </li>
                    <li> <a href=""> <i class="fa fa-instagram" aria-hidden="true"></i>  </a> </li>
                    <li> <a href=""> <i class="fa fa-pinterest-p" aria-hidden="true"></i>  </a> </li>
                </ul>
                <p>&copy; <a href="<?php echo e(config('app.url')); ?>"><?php echo e(config('app.name')); ?></a> | Todos os direitos reservados</p>
                <p>Todas as imagens disponivel neste site e as descrições pertencem ao site:<a href="http://i9life.global" target="blanck"> I9Life</a></p>

            </div>
        </div>
    </div>
</footer>