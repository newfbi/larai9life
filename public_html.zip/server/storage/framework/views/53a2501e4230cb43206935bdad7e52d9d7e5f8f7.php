<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
        <?php echo $__env->make('layouts.errors-and-messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="box">
            <form action="<?php echo e(route('admin.attributes.store')); ?>" method="post" class="form">
                <div class="box-body">
                    <div class="row">
                        <?php echo e(csrf_field()); ?>

                        <div class="col-md-12">
                            <div class="form-group">
                                <label for="name">Valor do atributo <span class="text-danger">*</span></label>
                                <input type="text" name="name" id="name" placeholder="Nome do atributo" class="form-control" value="<?php echo old('name'); ?>">
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.box-body -->
                <div class="box-footer">
                    <div class="btn-group">
                        <a href="<?php echo e(route('admin.attributes.index')); ?>" class="btn btn-default">Voltar</a>
                        <button type="submit" class="btn btn-primary">Criar</button>
                    </div>
                </div>
            </form>
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>