<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Versão</b> 1.0
    </div>
    <strong>Copyright &copy; <?php echo e(date('Y')); ?> - <?php echo e(date('Y') + 1); ?> <a href="<?php echo e(config('app.url')); ?>"><?php echo e(config('app.name')); ?></a>.</strong> Todos os direitos reservados.
</footer>